from django.apps import AppConfig


class SmarttmWebConfig(AppConfig):
    name = 'smarttm_web'
